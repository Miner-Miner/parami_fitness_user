import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../models/gym_models.dart';
import '../ui/app_theme.dart';
import '../ui/ui_parts.dart';

class QrScreen extends StatelessWidget {
  const QrScreen({super.key, required this.session});

  final AuthSession session;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
        children: [
          Text(
            'QR Pass',
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
              color: AppColors.ink,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'This QR code is generated locally from your member and user IDs.',
            style: TextStyle(color: AppColors.muted, height: 1.45),
          ),
          const SizedBox(height: 18),
          AppSurface(
            padding: const EdgeInsets.all(22),
            child: Column(
              children: [
                Text(
                  session.name,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    color: AppColors.ink,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  session.memberId.isEmpty
                      ? 'Member ID unavailable'
                      : session.memberId,
                  style: const TextStyle(color: AppColors.muted),
                ),
                const SizedBox(height: 18),
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: AppColors.line),
                  ),
                  child: QrImageView(
                    data: session.qrPayload,
                    size: 260,
                    eyeStyle: const QrEyeStyle(
                      eyeShape: QrEyeShape.square,
                      color: AppColors.navy,
                    ),
                    dataModuleStyle: const QrDataModuleStyle(
                      dataModuleShape: QrDataModuleShape.square,
                      color: AppColors.mintDark,
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                const Text(
                  'Show this QR at the gym entrance or staff desk.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.muted, height: 1.45),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          AppSurface(
            child: Row(
              children: [
                const Icon(Icons.badge_rounded, color: AppColors.mintDark),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Payload: ${session.qrPayload}',
                    style: const TextStyle(
                      color: AppColors.ink,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
